/*
 * ============================================================================
 *
 *       Filename:  action.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年01月15日 16时26分53秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * ============================================================================
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>

/* inet_ntoa */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "api.h"
#include "sysdef.h"
#include "serd.h"
#include "common.h"
#include "serapi.h"

void cmd_listclass(int fd)
{
	struct cliclass_t *ptr, *tmp;
	dprintf(fd, "Class list:\r\n");

	pthread_mutex_lock(&classlock);
	HASH_ITER(hh, classhead, ptr, tmp) {
		dprintf(fd, "%u\t%s\r\n", ptr->classid, ptr->cliclass);
	}
	pthread_mutex_unlock(&classlock);
}

void cmd_listcli(int fd)
{
	int totalcli = 0, classcli;
	char *macstr;
	struct cliclass_t *class, *tmp;
	struct client_t *cli;
	pthread_mutex_lock(&classlock);
	HASH_ITER(hh, classhead, class, tmp) {
		dprintf(fd, "%s\r\n", class->cliclass);
		classcli = 0;

		pthread_mutex_lock(&class->lock);
		list_for_each_entry(cli, &class->clilist, 
			classlist) {
			macstr = getmacstr(cli->mac);
			if(macstr) {
				classcli++;
				dprintf(fd, "\t%d : %s %s %s\r\n", 
					cli->sock, macstr,
					inet_ntoa(cli->cliaddr.sin_addr),
					cli->position);
				free(macstr);
			}
		}
		pthread_mutex_unlock(&class->lock);
		dprintf(fd, "\t%s : %d\r\n", 
			class->cliclass, classcli);
		totalcli += classcli;
	}
	pthread_mutex_unlock(&classlock);
	dprintf(fd, "total client: %d\r\n", totalcli);
}

void cmd_listclasscli(int fd, FILE *file)
{
	int i;
	dprintf(fd, "Input classid:\r\n");
	char classid[DEVID_LEN];
	for(i = 0; i < DEVID_LEN; i++) {
		classid[i] = getc(file);
		if(classid[i] == '\n')
			break;
	}
	classid[i] = 0;
	uint32_t id = strtol(classid, NULL, 10);

	int totalcli = 0, classcli;
	char *macstr;
	struct cliclass_t *class, *tmp;
	struct client_t *cli;
	pthread_mutex_lock(&classlock);
	HASH_ITER(hh, classhead, class, tmp) {
		if(id != class->classid)
			continue;
		dprintf(fd, "%u\t%s\r\n", class->classid, class->cliclass);
		classcli = 0;

		pthread_mutex_lock(&class->lock);
		list_for_each_entry(cli, &class->clilist, 
			classlist) {
			macstr = getmacstr(cli->mac);
			if(macstr) {
				classcli++;
				dprintf(fd, "\t%d : %s %s %s\r\n", 
					cli->sock, macstr,
					inet_ntoa(cli->cliaddr.sin_addr),
					cli->position);
				free(macstr);
			}
		}
		pthread_mutex_unlock(&class->lock);
		dprintf(fd, "\t%u\t%s : %d\r\n", 
			class->classid, class->cliclass, classcli);
		totalcli += classcli;
	}
	pthread_mutex_unlock(&classlock);
	dprintf(fd, "total client: %d\r\n", totalcli);
}

void cmd_sendcmd(int fd, FILE *file)
{
	int i;
	dprintf(fd, "Input classid:\r\n");
	char classid[DEVID_LEN];
	for(i = 0; i < DEVID_LEN; i++) {
		classid[i] = getc(file);
		if(classid[i] == '\n')
			break;
	}
	classid[i] = 0;
	uint32_t id = strtol(classid, NULL, 10);

	dprintf(fd, "Input count:\r\n");
	int c = 0;
	char count[10];
	for(i = 0; i < 9; i++) {
		count[i] = getc(file);
		if(count[i] == '\n')
			break;
	}
	count[i] = 0;
	c = strtol(count, NULL, 10);

	dprintf(fd, "Input cmd:\r\n");
	static char cmd[CMDLEN];
	for(i = 0; i < CMDLEN; i++) {
		cmd[i] = getc(file);
		if(cmd[i] == '\n')
			break;
	}
	cmd[i] = 0;

	dprintf(fd, "Input interval:\r\n");
	static char itv[10];
	for(i = 0; i < 10; i++) {
		itv[i] = getc(file);
		if(itv[i] == '\n')
			break;
	}
	itv[i] = 0;
	uint32_t sitv = strtol(itv, NULL, 10);

	struct cliclass_t *class, *tmp;
	struct client_t *cli;
	pthread_mutex_lock(&classlock);
	HASH_ITER(hh, classhead, class, tmp) {
		if(id != class->classid)
			continue;

		pthread_mutex_lock(&class->lock);
		i = 0;
		list_for_each_entry(cli, &class->clilist, classlist) {
			if(i > c)
				break;
			pthread_mutex_lock(&cli->lock);
			if(open_outfd(cli)) {
				time_t now = time(NULL);
				char *nowstr = ctime(&now);
				nowstr[strlen(nowstr) - 1] = 0;
				fprintf(cli->outfile, "[%s] '%s'\r\n", 
						nowstr, cmd);
				fflush(cli->outfile);
				close_outfd(cli);
			}
			pthread_mutex_unlock(&cli->lock);

			if(ssend_cmd(cli->sock, cmd) <= 0)
				continue;
			dprintf(fd, "Send cmd: %05d\r", ++i);
			if(i % 100 == 0)
				sleep(sitv);
		}
		pthread_mutex_unlock(&class->lock);
	}
	pthread_mutex_unlock(&classlock);
	return;
}

void *cmd_heartbeat(void *arg)
{
	char cmd[] = "uptime";

	struct cliclass_t *class, *tmp;
	struct client_t *cli;
	while(1) {
		pthread_mutex_lock(&classlock);
		HASH_ITER(hh, classhead, class, tmp) {
			pthread_mutex_lock(&class->lock);
			list_for_each_entry(cli, &class->clilist, classlist) {
				pthread_mutex_lock(&cli->lock);
				if(open_outfd(cli)) {
					time_t now = time(NULL);
					char *nowstr = ctime(&now);
					nowstr[strlen(nowstr) - 1] = 0;
					fprintf(cli->outfile, "[%s] '%s'\r\n", 
						nowstr, cmd);
					fflush(cli->outfile);
					close_outfd(cli);
				}
				pthread_mutex_unlock(&cli->lock);

				if(ssend_cmd(cli->sock, cmd) <= 0)
					continue;
			}
			pthread_mutex_unlock(&class->lock);
		}
		pthread_mutex_unlock(&classlock);
		sleep(20);
	}
	return NULL;
}

void command_init()
{
	if(Pthread_create(cmd_heartbeat, NULL))
		exit(-1);
}
