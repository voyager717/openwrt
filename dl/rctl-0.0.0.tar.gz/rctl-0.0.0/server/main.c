/*
 * ============================================================================
 *
 *       Filename:  ser.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年12月30日 11时26分37秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * ============================================================================
 */
#include <stdio.h>
#include <stdint.h>
#include <signal.h>
#include <unistd.h>
#include <sys/un.h>
#include <stdlib.h>
#include <time.h>

#include "common.h"
#include "bash.h"
#include "epoll.h"
#include "action.h"
#include "log.h"
#include "serapi.h"
#include "arg.h"

time_t starttime;
time_t runtime;

#define BUFLEN (2048)
void *command(void *arg)
{
	int clifd = (int)arg;
	FILE *clifp = fdopen(clifd, "a+");
	if(!clifp) {
		sys_err("fdopen clifd %d failed\r\n", clifd);
		return NULL;
	}
	pid_t pid;
	ssize_t ret;
	ret = read(clifd, &pid, sizeof(pid_t));
	if(ret != 4) {
		sys_err("can not get clild pid\n");
		fclose(clifp);
		return NULL;
	}
	sys_debug("new client: %u\n", pid);

	char recvbuf[BUFLEN];
	int i, num;
	while(1) {
		runtime = time(NULL) - starttime;
		dprintf(clifd, "\r\nuptime: %lud%luh%lum%lus\r\n", 
			runtime/3600/24, (runtime/3600)%24, 
			(runtime/60)%60, runtime%60);
		dprintf(clifd, "1: list all class\r\n");
		dprintf(clifd, "2: list all client\r\n");
		dprintf(clifd, "3: list clients in class\r\n");
		dprintf(clifd, "4: send command to all client\r\n");
		dprintf(clifd, "5: connect bash to client\r\n");
		dprintf(clifd, "6: connect bash to client name\r\n");

		for(i = 0; i < BUFLEN ; i++) {
			recvbuf[i] = getc(clifp);
			if(recvbuf[i] == EOF)
				goto end;
			if(recvbuf[i] == '\n')
				break;
		}
		/* skip strtol */
		recvbuf[i] = '&';

		errno = 0;
		num = strtol(recvbuf, NULL, 10);
		if(errno) continue;

		switch(num) {
		case 1:
			cmd_listclass(clifd);
			break;
		case 2:
			cmd_listcli(clifd);
			break;
		case 3:
			cmd_listclasscli(clifd, clifp);
			break;
		case 4:
			cmd_sendcmd(clifd, clifp);
			break;
		case 5:
			cmd_bashto(pid, clifd, clifp);
			break;
		case 6:
			cmd_bashto_name(pid, clifd, clifp);
			break;
		default:
			dprintf(clifd, "unknow command type: %d\r\n", num);
		}
	}
end:
	fclose(clifp);
	sys_debug("client close\n");
	return NULL;
}

void *_unsock_init(void *arg)
{
	int fd;
	struct sockaddr_un un;
	un.sun_family = AF_UNIX;
	strcpy(un.sun_path, UNNAME);
	if((fd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
		sys_err("create unix socket failed\r\n");
		exit(-1);
	}

	int size = offsetof(struct sockaddr_un, sun_path) + strlen(un.sun_path);

	unlink(un.sun_path);
	if(bind(fd, (struct sockaddr *)&un, size) < 0) {
		sys_err("bind unix socket to %s failed\r\n", un.sun_path);
		exit(-1);
	}

	if(listen(fd, 1)) {
		sys_err("listen socket failed\r\n");
		exit(-1);
	}

	int clifd,ret;
	socklen_t len = sizeof(un);
	while(1) {
		sys_debug("waiting new client\r\n");
		clifd = accept(fd, (struct sockaddr *)&un, &len);
		if(clifd < 0) {
			sys_warn("accpet client failed\r\n");
			continue;
		}

		pthread_t thread;
		ret = pthread_create(&thread, NULL, command, (void *)clifd);
		if(ret != 0) {
			sys_err("create pthread: %s(%d)\r\n",
				strerror(errno), errno);
			continue;
		}
	}

	return NULL;
}

void unsock_init()
{
	Pthread_create(_unsock_init, NULL);
}

static void signal_init()
{
	struct sigaction act;
	memset(&act, 0, sizeof(act));
	act.sa_handler = SIG_IGN;
	sigaction(SIGPIPE, &act, NULL);
	sigaction(SIGALRM, &act, NULL);
}

int main(int argc, char *argv[])
{
	starttime = time(NULL);
	proc_args(argc, argv);
	if(args_info.daemon_flag)
		daemon(0, 0);

	signal_init();
	epoll_init();
	//command_init();
	unsock_init();
	bash_init();
	serd_init();

	return 0;
}

