/*
 * ============================================================================
 *
 *       Filename:  serapi.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年01月17日 21时33分36秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * ============================================================================
 */
#include <stdio.h>
#include <stdint.h>
#include <pthread.h>

#include "log.h"

int Pthread_create(void *(*start_routine) (void *), void *arg)
{
	int ret;
	pthread_t thread;
	ret = pthread_create(&thread, NULL, start_routine, arg);
	if(ret)
		fprintf(stderr, "Pthread_create failed: %s\n", 
			strerror(errno));
	return ret;
}

