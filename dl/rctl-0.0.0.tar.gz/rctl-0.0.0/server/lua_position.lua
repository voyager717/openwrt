api=[[http://ip.taobao.com/service/getIpInfo.php?ip=<ip>]]
url=string.gsub(api, "<ip>", ... )

local http = require("socket.http")

repeat
out, err = http.request(url)
until err == 200

if out == nil then
	print(err)
	return false, err
end

local json = require "rctlser.json"
outtable = json.decode(out)

if outtable.data.city == "" then
	outtable.data.city = "localhost"
end

if outtable.data.isp == "" then
	outtable.data.isp = "nil"
end

return true, tostring(outtable.data.city) .. "(" .. tostring(outtable.data.isp) .. ")"
