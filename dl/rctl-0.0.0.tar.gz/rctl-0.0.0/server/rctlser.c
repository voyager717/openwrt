/*
 * ============================================================================
 *
 *       Filename:  main.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年08月06日 11时13分34秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * ============================================================================
 */
#include "config.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <stddef.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <termios.h>
#include <signal.h>

#include "log.h"

int debug = 1;
int daemon_enable = 0;
 
static struct termios tin;

static void terminal_set(int signo)
{
	static struct termios tlocal;
	memcpy(&tlocal, &tin, sizeof(tin));
	cfmakeraw(&tlocal);
	tcsetattr(STDIN_FILENO,TCSANOW,&tlocal);
}

static void terminal_reset(int signo)
{
	tcsetattr(STDIN_FILENO,TCSANOW,&tin);
	if(signo != SIGUSR2)
		exit(signo);
}

static void signal_init()
{
	struct sigaction act;
	memset(&act, 0, sizeof(act));
	act.sa_handler = terminal_set;
	sigaction(SIGUSR1, &act, NULL);
	act.sa_handler = terminal_reset;
	sigaction(SIGUSR2, &act, NULL);

	sigaction(SIGPIPE, &act, NULL);
	sigaction(SIGTERM, &act, NULL);
	sigaction(SIGINT, &act, NULL); 
	sigaction(SIGKILL, &act, NULL); 
	sigaction(SIGHUP, &act, NULL); 
}


ssize_t Read(int fildes, void *buf, size_t nbyte)
{
	ssize_t ret;
retry:
	ret = read(fildes, buf, nbyte);
	if(ret < 0 && errno == EINTR)
		goto retry;
	return ret;
}

ssize_t Write(int fildes, const void *buf, size_t nbyte)
{
	ssize_t ret;
retry:
	ret = write(fildes, buf, nbyte);
	if(ret < 0 && errno == EINTR)
		goto retry;
	return ret;
}
int main()
{
	tcgetattr(STDIN_FILENO, &tin); 
	pid_t pid = getpid();
	signal_init();
	int fd, size;
	struct sockaddr_un un;
	un.sun_family = AF_UNIX;
	sprintf(un.sun_path, "%s%05d\n", "/tmp/", pid);
	if((fd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
		sys_err("create unix socket failed\n");
		exit(-1);
	}

	unlink(un.sun_path);
	size = offsetof(struct sockaddr_un, sun_path) + strlen(un.sun_path);
	if(bind(fd, (struct sockaddr *)&un, size) < 0) {
		sys_err("bind unix socket to %s failed\n", un.sun_path);
		exit(-1);
	}

	un.sun_family = AF_UNIX;
	strcpy(un.sun_path, UNNAME);
	size = offsetof(struct sockaddr_un, sun_path) + strlen(un.sun_path);
	if(connect(fd, (struct sockaddr *)&un, size) < 0) {
		sys_err("Connect server failed: %s(%d)\n",
			strerror(errno), errno);
		exit(-1);
	}
	write(fd, &pid, sizeof(pid_t));

#define BUFLEN (2048)
	char recvbuf[BUFLEN];
	int maxfd;
	fd_set rset, rbset;

	FD_ZERO(&rset);
	FD_SET(0, &rset);
	FD_SET(fd, &rset);
	rbset = rset;

	maxfd = fd + 1;

	int i, ret;
	ssize_t nread;
	while(1) {
		rset = rbset;
		ret = select(maxfd, &rset, NULL, NULL, NULL);
		if(ret < 0) {
			if(errno == EINTR)
				continue;
			break;
		}

		if(FD_ISSET(0, &rset)) {
			nread = Read(0, recvbuf, BUFLEN);
			if(Write(fd, recvbuf, nread) < 0) {
				sys_err("write to unix socket failed\n");
				break;
			}
		}

		if(FD_ISSET(fd, &rset)) {
			if( (nread = Read(fd, recvbuf, BUFLEN)) <= 0) {
				sys_err("read from unix socket failed\n");
				break;
			}
			Write(1, recvbuf, nread);
		}
	}
	terminal_reset(1);
	close(fd);
	return 0;
}
