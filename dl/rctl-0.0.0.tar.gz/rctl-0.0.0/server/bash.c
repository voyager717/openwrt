/*
 * ============================================================================
 *
 *       Filename:  bash.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年01月13日 14时09分27秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * ============================================================================
 */
#include <stdio.h>
#include <stdint.h>

#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <sys/epoll.h>
#include <sys/time.h>

#include "common.h"
#include "serd.h"
#include "api.h"
#include "serapi.h"
#include "sysdef.h"
#include "arg.h"
#include "log.h"
#include "bash.h"

int listenfd = -1;
char recvbuf[BUFLEN];

LIST_HEAD(acchead);
int waitcount = 0;
pthread_mutex_t acchead_lock = PTHREAD_MUTEX_INITIALIZER;

void *thread_bashfd(void *arg)
{
	struct accept_list_t  *pos;
	struct sockaddr_in cliaddr;
	socklen_t socklen = sizeof(struct sockaddr_in);
	int fd;
	while(1) {
		fd = Accept(listenfd, (struct sockaddr *)&cliaddr, &socklen);
		if(fd < 0) {
			if(errno == EINTR)
				continue;

			sys_debug("Accept addr failed: %s(%d)\r\n", 
				strerror(errno), errno);
			exit(-1);
		}

		if(!tcp_alive(fd)) {
			sys_debug("tcp alive failed: %s(%d)\r\n", 
				strerror(errno), errno);
			close(fd);
			continue;
		}

		int hit = 0;
		struct in_addr paddr;
		pthread_mutex_lock(&acchead_lock);
		list_for_each_entry(pos, &acchead, node) {
			if(cliaddr.sin_addr.s_addr == pos->addr || waitcount == 1) {
				paddr.s_addr = pos->addr;
				sys_debug("Accept addr is: %s, %s\r\n",
					inet_ntoa(cliaddr.sin_addr),
					inet_ntoa(paddr));
				pthread_mutex_lock(&pos->qlock);
				pos->clifd = fd;
				pthread_mutex_unlock(&pos->qlock);
				pthread_cond_signal(&pos->qready);
				hit = 1;
				break;
			}
		}
		if(hit != 1) {
			sys_debug("no bash shell waiting, close %d, %s\n",
				fd, inet_ntoa(cliaddr.sin_addr));
			close(fd);
		}
		pthread_mutex_unlock(&acchead_lock);
	}

	return NULL;
}

void bashto(int clifd, in_addr_t addr, int sock)
{
	ssize_t nread;
	int i, ret, fd;
	struct timespec tv;
	struct timeval now;
	struct accept_list_t *newacc = Malloc(sizeof(struct accept_list_t));
	pthread_cond_init(&newacc->qready, NULL);
	pthread_mutex_init(&newacc->qlock, NULL);
	INIT_LIST_HEAD(&newacc->node);
	newacc->addr = addr;
	newacc->clifd = -1;

	pthread_mutex_lock(&acchead_lock);
	list_add_tail(&newacc->node, &acchead);
	waitcount++;
	pthread_mutex_unlock(&acchead_lock);

	pthread_mutex_lock(&newacc->qlock);
	/* send rctlbash command */
	if(ssend_cmd(sock, RCTLBASH) < 0) {
		sys_debug("send bash command failed\n");
		pthread_mutex_unlock(&newacc->qlock);
		goto next;
	}
	sys_debug("send bash command success\n");
	
	gettimeofday(&now, NULL);
	tv.tv_sec = now.tv_sec + 20;
	tv.tv_nsec = 0;

	sys_debug("prepare cond wait\n");
	ret = pthread_cond_timedwait(&newacc->qready, &newacc->qlock, &tv);
	if(ret != 0) {
		sys_debug("pthread cond wait failed: %d\n", ret);
	} else {
		sys_debug("pthread cond wait success %d\n", ret);
	}
	pthread_mutex_unlock(&newacc->qlock);

next:
	fd = newacc->clifd;
	pthread_mutex_lock(&acchead_lock);
	list_del(&newacc->node);
	waitcount--;
	pthread_mutex_unlock(&acchead_lock);

	pthread_mutex_destroy(&newacc->qlock);
	pthread_cond_destroy(&newacc->qready);
	free(newacc);
	if(fd == -1) {
		sys_debug("bash connect timeout\n");
		return;
	}

	sys_debug("accept bash fd: %d\n", fd);

	int n, epollfd, nfds;
	epollfd = epoll_create(10);
	if (epollfd == -1) {
		sys_err("Create epoll failed\n");
		goto end1;
	}
	struct epoll_event ev, events[2];
	ev.events = EPOLLIN;
	ev.data.fd = fd;
	if (epoll_ctl(epollfd, EPOLL_CTL_ADD, fd, &ev) == -1) {
		sys_err("Add epoll failed\n");
		goto end;
	}

	ev.data.fd = clifd;
	if (epoll_ctl(epollfd, EPOLL_CTL_ADD, clifd, &ev) == -1) {
		sys_err("Add epoll failed\n");
		goto end;
	}

	while(1) {
		nfds = epoll_wait(epollfd, events, 2, -1);
		if (nfds == -1) {
			sys_err("epoll wait failed\n");
			goto end;
		}

		for (n = 0; n < nfds; ++n) {
			if (events[n].data.fd == clifd) {
				nread = read(clifd, recvbuf, BUFLEN);
				if(Send(fd, recvbuf, nread) < 0)
					goto end;
			} else if(events[n].data.fd == fd) {
				if( (nread = Recv(fd, recvbuf, BUFLEN)) < 0)
					goto end;
				/* connection close */
				if(nread == 0) {
					sys_debug("bash connection close\n");
					goto end;
				}
				write(clifd, recvbuf, nread);
			}
		}
	}
end:
	close(epollfd);
end1:
	close(fd);
}

void macstr_to_mac(char *macstr, char *mac)
{
	int i;
	char *next;
	for(i = 0; i < ETH_ALEN; i++) {
		mac[i] = (unsigned char)
			strtol(macstr, &next, 16);
		if(*next == '\0')
			break;
		macstr = next + 1;
	}
}

void cmd_bashto(int pid, int fd, FILE *file)
{
	dprintf(fd, "Input client id:\r\n");
	int i;
	char cliid[DEVID_LEN];
	for(i = 0; i < DEVID_LEN; i++) {
		cliid[i] = getc(file);
		if(cliid[i] == '\n')
			break;
	}
	cliid[i] = 0;
	uint32_t id = strtol(cliid, NULL, 10);

	struct client_t *cli;
	pthread_mutex_lock(&totlock);
	HASH_FIND(hh2, totheadid, &id, sizeof(id), cli);
	if(cli) {
		pthread_mutex_unlock(&totlock);
		kill(pid, SIGUSR1);
		bashto(fd, cli->cliaddr.sin_addr.s_addr, cli->sock);
		kill(pid, SIGUSR2);
		return;
	}

	/* if no find unlock */
	pthread_mutex_unlock(&totlock);
}

void cmd_bashto_name(int pid, int fd, FILE *file)
{
	dprintf(fd, "Input mac:\r\n");
	int i;
	char macstr[MACSTR];
	for(i = 0; i < MACSTR; i++)
		macstr[i] = getc(file);

	macstr[i - 1] = 0;
	char mac[ETH_ALEN];
	macstr_to_mac(macstr, mac);

	struct client_t *cli;
	pthread_mutex_lock(&totlock);
	HASH_FIND(hh, tothead, mac, 6, cli);
	if(cli) {
		pthread_mutex_unlock(&totlock);
		kill(pid, SIGUSR1);
		bashto(fd, cli->cliaddr.sin_addr.s_addr, cli->sock);
		kill(pid, SIGUSR2);
		return;
	}

	/* if no find unlock */
	pthread_mutex_unlock(&totlock);
}

static void bashfd_listen()
{
	printf("bash init\n");
	struct sockaddr_in bashaddr;
	listenfd = Socket(AF_INET, SOCK_STREAM, 0);
	if(listenfd < 0) {
		sys_err("bashfd error\n");
		goto err;
	}

	int flag = 1, len = sizeof(flag);
	if( Setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &flag, len)) {
		sys_err("setsockopt error\n");
		goto err;
	}

	bashaddr.sin_family = AF_INET;
	bashaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	bashaddr.sin_port = htons(args_info.bashport_arg);
	if(Bind(listenfd, (struct sockaddr *)&bashaddr, sizeof(bashaddr))) {
		sys_err("Bind error\n");
		goto err;
	}

	if(Listen(listenfd, 0)) {
		sys_err("Listen error\n");
		goto err;
	}

	return;
err:
	listenfd = -1;
	exit(-1);
}

void bash_init()
{
	bashfd_listen();
	Pthread_create(thread_bashfd, NULL);
}
