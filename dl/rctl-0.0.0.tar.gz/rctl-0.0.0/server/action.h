/*
 * =====================================================================================
 *
 *       Filename:  action.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年01月15日 16时28分35秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * =====================================================================================
 */
#ifndef __ACTION_H__
#define __ACTION_H__

void cmd_listclass(int fd);
void cmd_listcli(int fd);
void cmd_listclasscli(int fd, FILE *file);
void cmd_sendcmd(int fd, FILE *file);
void *cmd_heartbeat(void *arg);
void command_init();
#endif /* __ACTION_H__ */
