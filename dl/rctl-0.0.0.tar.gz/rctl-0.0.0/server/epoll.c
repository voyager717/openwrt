/*
 * ============================================================================
 *
 *       Filename:  epoll.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年01月13日 14时35分31秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * ============================================================================
 */
#include <stdio.h>
#include <stdint.h>
#include <assert.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <stdlib.h>

#include "serapi.h"
#include "api.h"
#include "common.h"
#include "log.h"
#include "epoll.h"

#define PARA_NUM 	(10)
static int ep = -1;

void epoll_insert(struct client_t *client)
{
	int fd = client->sock;
	struct epoll_event ev;
	memset(&ev, 0, sizeof(ev));
	ev.events |= EPOLLIN | EPOLLRDHUP | EPOLLERR | EPOLLONESHOT;
	ev.data.ptr = client;
	if(epoll_ctl(ep, EPOLL_CTL_ADD, fd, &ev) < -1) {
		sys_err("epoll ctl failed: %s(%d)\n",
			strerror(errno), errno);
		exit(-1);
	}
}

void epoll_rearm(struct client_t *client)
{
	int fd = client->sock;
	struct epoll_event ev;
	memset(&ev, 0, sizeof(ev));
	ev.events |= EPOLLIN | EPOLLRDHUP | EPOLLERR | EPOLLONESHOT;
	ev.data.ptr = client;
	if(epoll_ctl(ep, EPOLL_CTL_MOD, fd, &ev) < -1) {
		sys_err("epoll ctl failed: %s(%d)\n",
			strerror(errno), errno);
		exit(-1);
	}
}

void epoll_delete(struct client_t *client)
{
	int fd = client->sock;
	if(epoll_ctl(ep, EPOLL_CTL_DEL, fd, NULL) < -1) {
		sys_err("epoll ctl failed: %s(%d)\n",
			strerror(errno), errno);
		exit(-1);
	}
}

static void write_outfd(struct client_t *cli, int num)
{
	pthread_mutex_lock(&cli->lock);
	if(open_outfd(cli)) {
		write(cli->outfd, cli->recvbuf, num);
		close_outfd(cli);
	}
	pthread_mutex_unlock(&cli->lock);
}

void epoll_recv(struct client_t *cli)
{
	ssize_t num;
	num = Recv(cli->sock, cli->recvbuf, BUFLEN);
	if(num < 0) {
		cli_free(cli);
		return;
	}
	write_outfd(cli, num);
}

int Epoll_wait(struct epoll_event *ev)
{
	int num;
	do {
		num = epoll_wait(ep, ev, PARA_NUM, -1);
	} while(num < 0 && (errno == EINTR));
	if(num < 0) {
		sys_err("epoll wait: %s(%d)\n", 
			strerror(errno), errno);
		exit(-1);
	}
	return num;
}

#ifdef DEBUG
void debug_event(uint32_t event)
{
	if(event & EPOLLIN) sys_info("EPOLLIN ");
	if(event & EPOLLOUT) sys_info("EPOLLOUT ");
	if(event & EPOLLRDHUP) sys_info("EPOLLRDHUP ");
	if(event & EPOLLPRI) sys_info("EPOLLPRI ");
	if(event & EPOLLERR) sys_info("EPOLLERR ");
	if(event & EPOLLHUP) sys_info("EPOLLHUP ");
	if(event & EPOLLET) sys_info("EPOLLET ");
	if(event & EPOLLONESHOT) sys_info("EPOLLONESHOT ");
	sys_info("\r\n");
}
#else
#define debug_event(event) NULL
#endif

void *epoll_loop(void *arg)
{
	struct epoll_event *ev;
	ev = Malloc(sizeof(struct epoll_event) * PARA_NUM);
	if(!ev) exit(-1);

	int i, num;
	while(1) {
		num = Epoll_wait(ev);

		for(i = 0; i < num; i++) {
			debug_event(ev[i].events);
			/* socket colse will set 
			 * EPOLLRDHUP and EPOLLIN */
			if(ev[i].events & EPOLLRDHUP ||
				ev[i].events & EPOLLERR ||
				!(ev[i].events & EPOLLIN)) {
				cli_free(ev[i].data.ptr);
			} else {
				epoll_recv(ev[i].data.ptr);
				epoll_rearm(ev[i].data.ptr);
			}
		}
	}
}

void epoll_init()
{
	assert(ep < 0);
	ep = epoll_create(1);
	if(ep < 0) {
		sys_err("epoll create failed: %s(%d)\n",
			strerror(errno), errno);
		exit(-1);
	}
	if(Pthread_create(epoll_loop, NULL))
		exit(-1);
}

