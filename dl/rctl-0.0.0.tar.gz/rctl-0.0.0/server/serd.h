/*
 * =====================================================================================
 *
 *       Filename:  serd.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年01月07日 20时43分50秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * =====================================================================================
 */
#ifndef __SERD_H__
#define __SERD_H__
#include <netinet/in.h>
#include <pthread.h>
#include "list.h"
#include "sysdef.h"
#include "config.h"
#include "uthash/include/uthash.h"

struct cliclass_t {
	/* hash key */
	char 	cliclass[DEVID_LEN];
	int	classid;

	int 	count;
	pthread_mutex_t 	lock;

	struct list_head 	clilist;
	UT_hash_handle hh;
};

#define LUA_POS 	LUA_INSTALL_RCTLSERDIR "/lua_position.lua"

struct client_t {
	/* hash key */
	unsigned char 	mac[ETH_ALEN];
	int 	sock;

	pthread_mutex_t lock;
	struct cliclass_t *class;
	int 	count;

	struct 	sockaddr_in cliaddr;

	char 	position[BUFLEN];
	char 	recvbuf[BUFLEN];
	int 	outfd;
	FILE 	*outfile;

	struct list_head acceptlist;
	struct list_head totlist;
	struct list_head classlist;

	UT_hash_handle hh2;
	UT_hash_handle hh;
};

extern pthread_mutex_t classlock;
extern struct cliclass_t *classhead;
extern pthread_mutex_t totlock;
extern struct client_t *tothead;
extern struct client_t *totheadid;

void serd_init();
void cli_free(struct client_t *cli);
void close_outfd(struct client_t *cli);
int open_outfd(struct client_t *cli);
#endif /* __SERD_H__ */
