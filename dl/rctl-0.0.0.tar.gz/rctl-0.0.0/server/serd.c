/*
 * ============================================================================
 *
 *       Filename:  serd.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年01月07日 14时50分16秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * ============================================================================
 */
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/stat.h>
#include <linux/limits.h>
#include <fcntl.h>
#include <stdlib.h>
#include <assert.h>

/*inet_ntoa*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "common.h"
#include "epoll.h"
#include "serd.h"
#include "serapi.h"
#include "arg.h"

static char recvbuf[BUFLEN];

pthread_mutex_t classlock = PTHREAD_MUTEX_INITIALIZER;
struct cliclass_t *classhead;
pthread_mutex_t totlock = PTHREAD_MUTEX_INITIALIZER;
struct client_t *tothead = NULL;
struct client_t *totheadid = NULL;

void close_outfd(struct client_t *cli)
{
	//close(cli->outfd);
	fclose(cli->outfile);
	cli->outfd = -1;
	cli->outfile = NULL;
}

int open_outfd(struct client_t *cli)
{
	char path[PATH_MAX];
	char *macstr = getmacstr(cli->mac);
	mkdir("/tmp/rctld/", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	snprintf(path, PATH_MAX, "/tmp/rctld/%s_%s_%s",
		cli->class->cliclass,
		inet_ntoa(cli->cliaddr.sin_addr),
		macstr);
	if(macstr)
		free(macstr);

	cli->outfile = fopen(path, "a+");
	if(!cli->outfile) {
		sys_err("Open %s failed: %s(%d)\n", 
			path, strerror(errno), errno);
		cli->outfd = -1;
		return 0;
	}
	fflush(cli->outfile);
	cli->outfd = fileno(cli->outfile);
	return 1;
}

static void getclass(struct cliclass_t *class)
{
	class->count++;
}

static int putclass(struct cliclass_t *class)
{
	if(!(--class->count)) {
		HASH_DEL(classhead, class);
		return 1;
	}
	return 0;
}

static struct cliclass_t *newclass(char *classname, uint32_t id)
{
	struct cliclass_t *ptr, *tmp;
	pthread_mutex_lock(&classlock);
	HASH_FIND(hh, classhead, classname, strlen(classname), ptr);
	if(ptr) {
		pthread_mutex_lock(&ptr->lock);
		getclass(ptr);
		pthread_mutex_unlock(&ptr->lock);
		pthread_mutex_unlock(&classlock);
		return ptr;
	}

	struct cliclass_t *new =
		Malloc(sizeof(struct cliclass_t));
	if(!new) {
		pthread_mutex_unlock(&classlock);
		return NULL;
	}

	memset(new, 0, sizeof(struct cliclass_t));
	strncpy(new->cliclass, classname, DEVID_LEN);
	new->classid = id;
	INIT_LIST_HEAD(&new->clilist);
	pthread_mutex_init(&new->lock, NULL);
	pthread_mutex_lock(&new->lock);
	getclass(new);
	pthread_mutex_unlock(&new->lock);
	HASH_ADD(hh, classhead, cliclass, strlen(new->cliclass), new);

	pthread_mutex_unlock(&classlock);
	return new;
}

static void cli_get(struct client_t *cli)
{
	pthread_mutex_lock(&cli->lock);
	cli->count++;
	pthread_mutex_unlock(&cli->lock);
}

static void cli_put(struct client_t *cli)
{
	pthread_mutex_lock(&cli->lock);
	if(!(--cli->count)) {
		free(cli);
		return;
	}
	pthread_mutex_unlock(&cli->lock);
}

struct sync_t {
	int fd;
};

LIST_HEAD(accepthead);
pthread_mutex_t accceptlock = PTHREAD_MUTEX_INITIALIZER;

void *acceptpool(void *arg)
{
	int fd;
	struct client_t *new;
	struct reg_t reg;
	ssize_t nread;
	struct cliclass_t *class;
	char *classname;
	struct client_t *ptr;

	while(1) {
		pthread_mutex_lock(&accceptlock);
		if(list_empty(&accepthead)) {
			pthread_mutex_unlock(&accceptlock);
			usleep(200000);
			continue;
		}
		new = list_first_entry(&accepthead, struct client_t, acceptlist);
		list_del(&new->acceptlist);
		pthread_mutex_unlock(&accceptlock);

		fd = new->sock;

		nread = srecv(fd, (char *)&reg, sizeof(reg));
		if(nread != sizeof(reg)) goto clean;

		classname = reg.class;
		classname[DEVID_LEN - 1] = 0;
		if(!(class = newclass(classname, fd))) 
			goto clean;
		new->class = class;
		memcpy(new->mac, reg.mac, ETH_ALEN);
		pthread_mutex_init(&new->lock, NULL);
		cli_get(new);

		pthread_mutex_lock(&class->lock);
		pthread_mutex_lock(&totlock);
		HASH_FIND(hh, tothead, new->mac, 6, ptr);
		if(ptr) {
			HASH_DELETE(hh, tothead, ptr);
			list_del(&ptr->classlist);
			HASH_FIND(hh2, totheadid, 
				&(new->sock), sizeof(new->sock), ptr);
			if(ptr)
				HASH_DELETE(hh2, totheadid, ptr);
		}

		HASH_ADD(hh, tothead, mac, 6, new);
		HASH_ADD(hh2, totheadid, sock, 
			sizeof(new->sock), new);
		list_add_tail(&new->classlist, &class->clilist);
		epoll_insert(new);
		pthread_mutex_unlock(&totlock);
		pthread_mutex_unlock(&class->lock);
		continue;

clean:
		close(fd);
		free(new);
	}
}

static void accept_newcli(struct sync_t *sync)
{
	int sock = sync->fd;

	struct client_t *new;
	new = Malloc(sizeof(struct client_t));
	if(!new) return;
	memset(new, 0, sizeof(struct client_t));

	socklen_t socklen = sizeof(struct sockaddr_in);
	int fd = Accept(sock, (struct sockaddr *)&new->cliaddr, &socklen);
	if(fd < 0) goto clean;
	if(!tcp_alive(fd)) goto clean;

	pthread_mutex_lock(&accceptlock);
	new->sock = fd;
	list_add_tail(&(new->acceptlist), &accepthead);
	pthread_mutex_unlock(&accceptlock);
	return;

clean:
	free(new);
}

static void *rctlreg(void * arg)
{
	/* if port_given is 0, then use default */
	int total = (args_info.port_given) ? args_info.port_given : 1;
	struct sync_t *sync = Malloc(sizeof(struct sync_t) * total);
	struct sockaddr_in seraddr;
	memset(&seraddr, 0, sizeof(seraddr));

	int i, j, count, flag = 1, len = sizeof(flag);
	/* listen all support port */
	for(i = 0, j = 0, count = 0; i < total; i++) {
		/* enable socket reuse */
		sync[j].fd = Socket(AF_INET, SOCK_STREAM, 0);
		if(sync[j].fd < 0) continue;
		if(sync[j].fd > FD_SETSIZE) {
			sys_err("Listen fd %d exceed FD_SETSIZE: %d\n", sync[j].fd, FD_SETSIZE);
			exit(-1);
		}

		if( Setsockopt(sync[j].fd, SOL_SOCKET, SO_REUSEADDR, &flag, len))
			continue;

		/* Bind INADDR_ANY */
		seraddr.sin_family = AF_INET;
		seraddr.sin_addr.s_addr = htonl(INADDR_ANY);
		seraddr.sin_port = htons(args_info.port_arg[i]);
		if(Bind(sync[j].fd, (struct sockaddr *)&seraddr, sizeof(seraddr)))
			continue;

		/* Listen */
		if(Listen(sync[j].fd, SOMAXCONN))
			continue;
		sys_debug("listen %d\n", args_info.port_arg[i]);
		j++; count++;
	}

	/* select all listen fd */
	int maxfd = 0;
	fd_set rset, rsetbak;
	FD_ZERO(&rset);
	for(i = 0; i < count; i++) {
		FD_SET(sync[i].fd, &rset);
		maxfd = (maxfd > sync[i].fd) ? maxfd : sync[i].fd;
	}
	maxfd++;
	rsetbak = rset;

	/* accept client connect */
	int num;
	while(1) {
		rset = rsetbak;
		num = Select(maxfd, &rset, NULL, NULL, NULL);
		if(num == -1) continue;
		for(i = 0, j = 0; i < count && j < num; i++) {
			if(FD_ISSET(sync[i].fd, &rset)) {
				accept_newcli((void *)&sync[i]);
				j++;
			}
		}
	}
	free(sync);
	return NULL;
}

void cli_free(struct client_t *cli)
{
	int flag = 0;
	struct client_t *ptr;
	pthread_mutex_lock(&classlock);
	pthread_mutex_lock(&cli->class->lock);
	pthread_mutex_lock(&totlock);

	HASH_FIND(hh, tothead, cli->mac, 6, ptr);
	if(ptr)
		HASH_DELETE(hh, tothead, ptr);
	HASH_FIND(hh2, totheadid, &(cli->sock), sizeof(cli->sock), ptr);
	if(ptr)
		HASH_DELETE(hh2, totheadid, ptr);

	list_del(&cli->classlist);
	epoll_delete(cli);
	flag = putclass(cli->class);
	pthread_mutex_unlock(&totlock);
	pthread_mutex_unlock(&cli->class->lock);
	pthread_mutex_unlock(&classlock);

	close(cli->sock);

	if(flag) {
		pthread_mutex_destroy(&cli->class->lock);
		free(cli->class);
	}
	pthread_mutex_destroy(&cli->lock);
	cli_put(cli);
}

void serd_init()
{
	int i;
	for(i = 0; i < args_info.threadpool_arg; i++) {
		if(Pthread_create(acceptpool, NULL))
			exit(-1);
	}

	rctlreg(NULL);
}
