/*
 * =====================================================================================
 *
 *       Filename:  bash.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年01月13日 16时20分22秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * =====================================================================================
 */
#ifndef __BASH_H__
#define __BASH_H__
#include <stdio.h>
/* inet_addr */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <list.h>

struct accept_list_t {
	in_addr_t addr;
	int clifd;
	pthread_cond_t qready;
	pthread_mutex_t qlock;
	struct list_head node;
};

void bash_init();
void cmd_bashto(int pid, int fd, FILE *file);
#define TIMEOUT  "bash connect timeout\n"
#endif /* __BASH_H__ */
