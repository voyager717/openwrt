/*
 * =====================================================================================
 *
 *       Filename:  rctl.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年12月30日 09时48分58秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * =====================================================================================
 */
#ifndef __RCTL_H__
#define __RCTL_H__

void rctl();
#endif /* __RCTL_H__ */
