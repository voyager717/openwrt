/*
 * ============================================================================
 *
 *       Filename:  cli.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年12月30日 11时12分59秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * ============================================================================
 */
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/file.h>
#include <fcntl.h>
#include <errno.h>

#include "rctl.h"
#include "log.h"
static int one_instance()
{
	int pid_file = open("/var/run/kworker.pid", 
		O_CREAT | O_RDWR, 0666);
	int rc = flock(pid_file, LOCK_EX | LOCK_NB);
	if(rc) {
		if(EWOULDBLOCK == errno) {
			sys_warn("another kworker is running\n");
			return -1;
		}
	}
	return 0;
}

int main(int argc, char *argv[])
{
	if(one_instance() < 0)
		return 0;
	if(daemon_enable)
		daemon(0, 0);
	rctl(argc, argv);
	while(1)
		pause();
	return 0;
}
