/*
 * =====================================================================================
 *
 *       Filename:  exchange.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2015年01月14日 17时23分58秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * =====================================================================================
 */
#ifndef __EXCHANGE_H__
#define __EXCHANGE_H__

void exchange(int ptm, int fd);
#endif /* __EXCHANGE_H__ */
