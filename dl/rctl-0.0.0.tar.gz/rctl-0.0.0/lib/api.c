/*
 * ============================================================================
 *
 *       Filename:  lnet.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年12月30日 13时50分57秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jianxi sun (jianxi), ycsunjane@gmail.com
 *   Organization:  
 *
 * ============================================================================
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <sys/select.h>
#include <errno.h>
#include <sys/socket.h>
#include "log.h"

int Socket(int domain, int type, int protocol)
{
	int fd = socket(domain, type, protocol);
	if(fd < 0) {
		fprintf(stderr, "Create socket failed: %s\n", 
			strerror(errno));
		return -1;
	}
	return fd;
}

int Bind(int socket, const struct sockaddr *address,
	socklen_t address_len) 
{
	int ret = bind(socket, address, address_len);
	if(ret < 0) {
		fprintf(stderr, "Bind socket failed: %s\n", 
			strerror(errno));
		return -1;
	}
	return 0;
}

int Listen(int socket, int backlog)
{
	int ret = listen(socket, backlog);
	if(ret < 0) {
		fprintf(stderr, "Listen socket failed: %s\n", 
			strerror(errno));
		return -1;
	}
	return 0;
}

int Select(int nfds, fd_set * readfds,
	fd_set * writefds, fd_set * errorfds,
	struct timeval * timeout)
{
	int ret;
	do {
		ret = select(nfds, readfds, writefds, errorfds, 
			timeout);
	} while(ret < 0 && errno == EINTR);

	return ret;
}

int Accept(int socket, struct sockaddr * address,
	socklen_t * address_len)
{
	int fd;
	fd = accept(socket, address, address_len);
	if(fd < 0) {
		fprintf(stderr, "Accept socket failed: %s\n", 
			strerror(errno));
		return -1;
	}
	return fd;
}

ssize_t Recv(int socket, void *buffer, size_t length)
{
	ssize_t ret;
	do {
		ret = recv(socket, buffer, length, 0);
	} while(ret < 0 && errno == EINTR);

	return ret;
}

int srecv(int ssock, char *buffer, size_t length)
{
	if(ssock < 0)
		return -1;
	int rsize = 0;
	size_t tot = 0;
	do {
rerecv:
		rsize = recv(ssock, buffer, length, 0);
		if(rsize == 0) break;
		if(rsize < 0) {
			if(errno == EINTR)
				goto rerecv;
			sys_warn("Recv buffer failed: %s(%d)\n",
				strerror(errno), errno);
			return -1;
		}

		tot += rsize;
		buffer += rsize;
	} while(length -= rsize);
	return tot;
}

ssize_t Send(int ssock, char *buffer, size_t length)
{
	if(ssock < 0)
		return -1;
	int ssize = 0;
	size_t tot = 0;
	do {
resend:
		ssize = send(ssock, buffer, length, 0);
		if(ssize == 0) break;
		if(ssize < 0) {
			if(errno == EINTR)
				goto resend;
			sys_warn("Send buffer failed: %s(%d)\n",
				strerror(errno), errno);
			return -1;
		}

		tot += ssize;
		buffer += ssize;
	} while(length -= ssize);
	return tot;
}

void *Malloc(size_t size)
{
	void *ptr = malloc(size);
	if(!ptr) {
		fprintf(stderr, "Malloc failed: %s\n", 
			strerror(errno));
		return NULL;
	}
	return ptr;
}

int Setsockopt(int socket, int level, int option_name,
	const void *option_value, socklen_t option_len)
{
	int ret = setsockopt(socket, level, 
		option_name, option_value, option_len);
	if(ret < 0)
		fprintf(stderr, "Setsocket failed: %s\n", 
			strerror(errno));
	return ret;
}

