from compose.cli.main import main

main()
