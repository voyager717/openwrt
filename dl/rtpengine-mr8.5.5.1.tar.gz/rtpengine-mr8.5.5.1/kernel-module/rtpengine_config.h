/*
 * rtpengine_config.h
 *
 * Description: Config file with preprocessor config macros
 *
 *  Created on: Mar 18, 2015
 *      Author: fmetz
 */

#ifndef RTPENGINE_CONFIG_H_
#define RTPENGINE_CONFIG_H_

#define RE_HAS_MEASUREDELAY 0

#endif /* RTPENGINE_CONFIG_H_ */
