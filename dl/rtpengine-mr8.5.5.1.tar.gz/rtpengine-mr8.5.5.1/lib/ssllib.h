#ifndef __SSLLIB_H__
#define __SSLLIB_H__


void rtpe_ssl_init(void);


#endif
