Thanks!

* https://github.com/andy-maier
* https://github.com/SethMichaelLarson
* https://github.com/asottile
* https://github.com/MartijnBraam
* https://github.com/funkyfuture
* https://github.com/adamjstewart
* https://github.com/xavfernandez
* https://github.com/xsuchy
* https://github.com/marcoceppi
* https://github.com/tgamblin
* https://github.com/sebix
